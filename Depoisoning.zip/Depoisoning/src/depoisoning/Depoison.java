/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depoisoning;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import weka.classifiers.Evaluation;
import weka.classifiers.lazy.IBk;
import weka.classifiers.functions.LinearRegression;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.core.converters.CSVSaver;

/**
 *
 * @author 91790
 */
public class Depoison 
{
    Details dt=new Details();
    
    public String generatePoison(double p,String fileName)
    {
        String res="";
        try
        {
            
            
            CSVLoader csv=new CSVLoader();
            csv.setSource(new File(fileName));    
            Instances data=csv.getDataSet();
            data.setClassIndex(data.numAttributes()-1);
            int sz=(int)(p*data.numInstances());
            Random rm=new Random();
            ArrayList<Integer> at=new ArrayList<Integer>();            
            for(int i=0;i<sz;i++)
            {
                int r1=rm.nextInt(data.numInstances());
                if(at.contains(r1))
                {
                    i--;
                }
                else
                {
                    at.add(r1);
                    double e1=data.instance(r1).classValue();
                    
                    if(e1==0)
                        data.instance(r1).setClassValue(1);
                    else
                        data.instance(r1).setClassValue(0);
                    
              
                }
            }
            
            
            int pr=(int)(p*100);
            CSVSaver sav=new CSVSaver();
            sav.setRetrieval(1);
            sav.setInstances(data);
            sav.setFile(new File("pois-"+pr+".csv"));
            sav.writeBatch();
            
            
            System.out.println(fileName+" --- "+(p*100)+"% poision");
            res=process("pois-"+pr+".csv");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
    public String process(String fileName)
    {
        String res="";
        try
        {            
            
            CSVLoader csv=new CSVLoader();            
            csv.setSource(new File(fileName));
            Instances data=csv.getDataSet();      
            data.setClassIndex(data.numAttributes()-1);
            
            double org[]=new double[data.numInstances()];
            for(int i=0;i<org.length;i++)
                org[i]=data.get(i).classValue();
            IBk knn= new IBk();
            knn.buildClassifier(data);
            
            LinearRegression lr=new LinearRegression();
            lr.buildClassifier(data);
            
            RandomForest rf=new RandomForest();
            rf.buildClassifier(data);
            double knn1[]=new double[data.numInstances()];
            for(int i=0;i<data.numInstances();i++)
            {
                double e1=knn.classifyInstance(data.get(i));
                if(e1<0.5)
                    knn1[i]= 0;
                else
                    knn1[i]= 1;
            }
            
            double lr1[]=new double[data.numInstances()];
            for(int i=0;i<data.numInstances();i++)
            {
                double e1=lr.classifyInstance(data.get(i));
                if(e1<0.5)
                    lr1[i]=0;
                else
                    lr1[i]=1;
            }
            
            double rf1[]=new double[data.numInstances()];
            for(int i=0;i<data.numInstances();i++)
            {
                double e1=rf.classifyInstance(data.get(i));
                if(e1<0.5)
                    rf1[i]=0;
                else
                    rf1[i]=1;
            }
            
            Instances ud1=data;
            ud1.setClassIndex(ud1.numAttributes()-1);
            for(int i=0;i<ud1.numInstances();i++)
            {
                ud1.get(i).setClassValue(knn1[i]);
            }
            
            Instances ud2=ud1;
            ud2.setClassIndex(ud2.numAttributes()-1);
            for(int i=0;i<ud2.numInstances();i++)
            {
                ud2.get(i).setClassValue(lr1[i]);
            }
            
            Instances ud3=ud2;
            ud3.setClassIndex(ud3.numAttributes()-1);
            for(int i=0;i<ud3.numInstances();i++)
            {
                ud3.get(i).setClassValue(rf1[i]);
            }
            
            double knn2[]=new double[ud1.numInstances()];
            for(int i=0;i<ud1.numInstances();i++)
            {
                double e1=knn.classifyInstance(ud1.get(i));
                if(e1<0.5)
                    knn2[i]=0;
                else
                    knn2[i]=1;
            }
            
            double lr2[]=new double[ud2.numInstances()];
            for(int i=0;i<ud2.numInstances();i++)
            {
                double e1=lr.classifyInstance(ud2.get(i));
                if(e1<0.5)
                    lr2[i]=0;
                else
                    lr2[i]=1;
            }
            
            double rf2[]=new double[ud3.numInstances()];
            for(int i=0;i<ud3.numInstances();i++)
            {
                double e1=rf.classifyInstance(ud3.get(i));                
                if(e1<0.5)
                    rf2[i]=0;
                else
                    rf2[i]=1;
            }
            double p1[]=voting(knn1,lr1,rf1);
            double p2[]=voting(knn2,lr2,rf2);
            
            double clsin[]=new double[data.numInstances()];
            for(int i=0;i<ud3.numInstances();i++)
            {
                double e1=ud3.get(i).classValue();
                Instances dd=knn.getNearestNeighbourSearchAlgorithm().kNearestNeighbours(ud3.get(i), 20);      
                double sm=0;
                
                for(int j=0;j<dd.numInstances();j++)
                {
                    double e2=dd.get(j).classValue();
                    if(e1==e2)
                        sm=sm+1;                                           
                }
                sm=sm/(double)dd.numInstances();
                //System.out.println(sm);
                if(sm>0.5)
                {
                    ud3.instance(i).setClassValue(e1);                                    
                } 
                else
                {
                    if(e1==1)
                    {
                        ud3.instance(i).setClassValue(0);                     
                    }
                   
                }
            
            }
            
            
            res=getResult(ud3,p1,p2);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
    
    public double[] voting(double e1[],double e2[],double e3[])
    {
        double p1[]=new double[e1.length];
        try
        {
            for(int i=0;i<e1.length;i++)
            {
                //p1[i]=e1[i] == e2[i]? (e1[i] == e3[i] ? e1[i] : e3[i]) : (e2[i] == e3[i] ? e2[i] : e3[i]) ;
                if(e1[i]==0.0 && e2[i]==0.0 && e3[i] ==0.0)
                   p1[i]=0;
               else if(e1[i]==0.0 && e2[i]==0.0 && e3[i]==1.0)
                   p1[i]=0;
               else if(e1[i]==0.0 && e2[i]==1.0 && e3[i]==0.0)
                   p1[i]=0;
               else if(e1[i]==0.0 && e2[i]==1.0 && e3[i]==1.0)
                   p1[i]=1;
               else if(e1[i]==1.0 && e2[i]==0.0 && e3[i]==0.0)
                   p1[i]=0;
               else if(e1[i]==1.0 && e2[i]==0.0 && e3[i]==1.0)
                   p1[i]=1;
               else if(e1[i]==1.0 && e2[i]==1.0 && e3[i]==0.0)
                   p1[i]=1;
               else
                   p1[i]=1;                           
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return p1;
    }
    
    public String getResult(Instances data,double clsin1[], double clsin2[])
    {
        String res="";
        try
        {
            IBk cls=new IBk();            
            data.setClassIndex(data.numAttributes()-1);
            //cls.buildClassifier(data);
            Evaluation eval = new Evaluation(data);
            
            Random rand = new Random(1);  
            int folds = 10; 
            eval.crossValidateModel(cls, data, folds, rand);
            cls.buildClassifier(data);                   
            double mae=eval.meanAbsoluteError();
            double rmse=eval.rootMeanSquaredError();
            double cc=eval.correlationCoefficient();
            double cr1=0;
            double cr2=0;
            for(int i=0;i<data.numInstances();i++)
            {
                if(clsin1[i]==data.instance(i).classValue())
                    cr1++;
                
                if(clsin2[i]==data.instance(i).classValue())
                    cr2++;
            }
            
            double acc1=(cr1/(double)data.numInstances())*100;
            double acc2=(cr2/(double)data.numInstances())*100;
            
            //if(acc1>acc2)
                System.out.println("Accuracy = "+acc1+" : "+acc2);
            //else
              //  System.out.println("Accuracy = "+acc2);
            System.out.println("MAE = "+mae);
            System.out.println("RMSE = "+rmse);
            System.out.println("CC = "+cc);
            
            res=acc1+"#"+cc+"#"+mae+"#"+rmse;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return res;
    }
}
