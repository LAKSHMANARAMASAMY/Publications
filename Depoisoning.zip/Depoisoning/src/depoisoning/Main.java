/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depoisoning;

/**
 *
 * @author 91790
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Details dt=new Details();
        Depoison ks=new Depoison();        
               
        for(int i=0;i<dt.in1.length;i++)
        {
            String rr="";
            for(int j=0;j<dt.poisr.length;j++)
            {
                String res=ks.generatePoison(dt.poisr[j], dt.in1[i]);                
                rr=rr+res+"@";
            }
            dt.results[i]=rr;
        }
        Graph gr=new Graph();
    }
    
}
