/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depoisoning;

/**
 *
 * @author 91790
 */
public class Details 
{
    //String input="h1.csv";
    //String input="diabetes.csv";
    //String input="IoT_GPS_Tracker.csv";
    String input="IoT_Weather.csv";
    
    String pois="pois.csv";
    static double poisRate=0;
    
    String in1[]={"h1.csv","diabetes.csv","IoT_GPS_Tracker.csv","IoT_Weather.csv"};
    
    static double poisr[]={0,0.05,0.1,0.15,0.2,0.25};
    
    String ins[]={"Heart","Diabetes","IoT_GPS_Tracker","IoT_Weather"};
    static String results[]=new String[4];
}
