/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depoisoning;

import java.awt.Color;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author 91790
 */
public class Graph 
{
    Details dt=new Details();
    Graph()
    {
        
        /*for(int i=0;i<dt.results.length;i++)
        {
            String r1[]=dt.results[i].split("@");            
            String acc="";
            String cc="";
            String mae="";
            String rmse="";
            for(int j=0;j<r1.length;j++)
            {
                String r2[]=r1[j].split("#");
                acc=acc+r2[0]+"#";
                cc=cc+r2[1]+"#";
                mae=mae+r2[2]+"#";
                rmse=rmse+r2[3]+"#";
            }
            System.out.println(acc);
            System.out.println(cc);
            System.out.println(mae);
            System.out.println(rmse);
            Graph1(dt.ins[i],"ACC",acc);
            Graph1(dt.ins[i],"CC",cc);
            Graph1(dt.ins[i],"MAE",mae);
            Graph1(dt.ins[i],"RMSE",rmse);
        }*/
        
        String acc="";
        String cc="";
        String mae="";
        String rmse="";
        
        for(int i=0;i<dt.results.length;i++)
        {
            String r1[]=dt.results[i].split("@");            
            for(int j=0;j<r1.length;j++)
            {
                String r2[]=r1[j].split("#");
                acc=acc+r2[0]+"#";
                cc=cc+r2[1]+"#";
                mae=mae+r2[2]+"#";
                rmse=rmse+r2[3]+"#";
            }
            acc=acc+"@";
            cc=cc+"@";
            mae=mae+"@";
            rmse=rmse+"@";            
        }
        Graph1("ACC",acc);
        Graph1("CC",cc);
        Graph1("MAE",mae);
        Graph1("RMSE",rmse);
    }
    
    public void Graph1(String ms,String val)
    {
        try
        {
            String ch1[]={"0%","5%","10%","15%","20","25"};
            
            String v[]=val.split("@");

            // create the dataset...
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for(int j=0;j<v.length;j++)
            {
                String vss[]=v[j].split("#");
                for(int i=0;i<vss.length;i++)
                    dataset.addValue(Double.parseDouble(vss[i]), dt.in1[j], ch1[i]);
            }
            
            
            JFreeChart chart = ChartFactory.createLineChart(
            ms+" Comparison",
            "Data Poison Rate (%)",        
            ms,         
            dataset,             
            PlotOrientation.VERTICAL, 
            true,                     
            true,                     
            false                     
        );

            chart.setBackgroundPaint(Color.white);

      CategoryPlot plot = (CategoryPlot) chart.getPlot();
	 
        plot.setBackgroundPaint(Color.lightGray);
        plot.setRangeGridlinePaint(Color.white);

        
		
	 LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setSeriesLinesVisible(0, true);
        renderer.setSeriesShapesVisible(1, true);
	renderer.setSeriesShapesVisible(2, true);
        renderer.setSeriesPaint(0, Color.blue);
        renderer.setSeriesPaint(1, Color.red);
        renderer.setSeriesPaint(2, Color.green);
        renderer.setSeriesPaint(3, Color.magenta);
        plot.setRenderer(renderer);
		
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
            rangeAxis.setStandardTickUnits(NumberAxis.createStandardTickUnits());//.createIntegerTickUnits());
              rangeAxis.setAutoRangeIncludesZero(true);
            //rangeAxis.setRange(70, 100);
            
         ChartFrame frame1=new ChartFrame("Comparison - "+ms,chart);
  
            frame1.setSize(500,400);
  
            frame1.setVisible(true);   
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}
