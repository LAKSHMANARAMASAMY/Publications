/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depoisoning;

import java.io.File;
import java.util.Random;
import weka.classifiers.Evaluation;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.core.converters.CSVSaver;
import weka.classifiers.lazy.IBk;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author 91790
 */
public class KSSD 
{
    Details dt=new Details();
    
    KSSD()
    {
        
    }
    
    public void generatePoison(double p,String fileName)
    {
        try
        {
            //File fe=new File("pois.csv");
            //if(!fe.exists())
              //  fe.delete();
            
            CSVLoader csv=new CSVLoader();
            csv.setSource(new File(fileName));    // orginal            
            Instances data=csv.getDataSet();
            data.setClassIndex(data.numAttributes()-1);
            int sz=(int)(p*data.numInstances());
            Random rm=new Random();
            ArrayList<Integer> at=new ArrayList<Integer>();            
            for(int i=0;i<sz;i++)
            {
                int r1=rm.nextInt(data.numInstances());
                if(at.contains(r1))
                {
                    i--;
                }
                else
                {
                    at.add(r1);
                    double e1=data.instance(r1).classValue();
                    
                    if(e1==0)
                        data.instance(r1).setClassValue(1);
                    else
                        data.instance(r1).setClassValue(0);
                    
              //      System.out.println(r1+" : "+ e1+" : "+data.instance(r1).classValue());
                }
            }
            
            //System.out.println(at);
            int pr=(int)(p*100);
            CSVSaver sav=new CSVSaver();
            sav.setRetrieval(1);
            sav.setInstances(data);
            sav.setFile(new File("pois-"+pr+".csv"));
            sav.writeBatch();
            
            
            System.out.println(fileName+" --- "+(p*100)+"% poision");
            processKSSD("pois-"+pr+".csv");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public void processKSSD(String fileName)
    {
        try
        {            
            
            CSVLoader csv=new CSVLoader();
            //csv.setSource(new File(dt.input));    // orginal
            //csv.setSource(new File(dt.pois));    // poison data
            csv.setSource(new File(fileName));
            Instances data=csv.getDataSet();
            data.setClassIndex(data.numAttributes()-1);
            IBk knn1= new IBk();
            knn1.buildClassifier(data);
            
            double clsin[]=new double[data.numInstances()];
            for(int i=0;i<data.numInstances();i++)
            {
                double e1=data.get(i).classValue();
                Instances dd=knn1.getNearestNeighbourSearchAlgorithm().kNearestNeighbours(data.get(i), 10);                //System.out.println(e1);
                double sm=0;
                
                for(int j=0;j<dd.numInstances();j++)
                {
                    double e2=dd.get(j).classValue();
                    if(e1==e2)
                        sm=sm+1;                                           
                }
                sm=sm/(double)dd.numInstances();
                //System.out.println(sm);
                /*if(sm>0.5)
                {
                    data.instance(i).setClassValue(e1);                
                } 
                clsin[i]=e1;*/
                
                 if(sm>0.5)
                {
                    data.instance(i).setClassValue(e1);                
                    //clsin[i]=e1;
                } 
                else
                {
                    if(e1==1)
                    {
                        data.instance(i).setClassValue(0);   
                      //  clsin[i]=0;
                    }
                    else
                    {
                        data.instance(i).setClassValue(1);   
                        //clsin[i]=1;
                    }
                }
                clsin[i]=e1;
                //clsin[i]=data.instance(i).classValue();
               
               
                //System.out.println(e1+" : "+data.instance(i).classValue());
            }
            
            getResult(data,clsin);
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public void getResult(Instances data,double clsin[])
    {
        try
        {
            IBk cls=new IBk();
            data.setClassIndex(data.numAttributes()-1);
            //cls.buildClassifier(data);
            Evaluation eval = new Evaluation(data);
            
            Random rand = new Random(1);  // using seed = 1
            int folds = 10; //10 fold Cross Validation
            eval.crossValidateModel(cls, data, folds, rand);
            cls.buildClassifier(data);                   
            double mae=eval.meanAbsoluteError();
            double rmse=eval.rootMeanSquaredError();
            double cc=eval.correlationCoefficient();
            double cr=0;
            for(int i=0;i<data.numInstances();i++)
            {
                if(clsin[i]==data.instance(i).classValue())
                    cr++;
            }
            
            double acc=(cr/(double)data.numInstances())*100;
            
            System.out.println("Accuracy = "+acc);
            System.out.println("MAE = "+mae);
            System.out.println("RMSE = "+rmse);
            System.out.println("CC = "+cc);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
